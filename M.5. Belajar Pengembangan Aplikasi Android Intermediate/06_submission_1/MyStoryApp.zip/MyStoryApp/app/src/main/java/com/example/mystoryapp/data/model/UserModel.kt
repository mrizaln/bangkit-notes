package com.example.mystoryapp.data.model

data class UserModel(
    val name: String,
    val email: String,
    val userId: String,
    val token: String,
)